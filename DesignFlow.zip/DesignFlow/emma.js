document.getElementById('Footer1').scrollIntoView()

const Toggle_Styling = () => {
    console.log('test')
    document.getElementById('FixedStyledElements').classList.toggle('Open')
}